rootProject.name = "MemoryCue"
include(":app")