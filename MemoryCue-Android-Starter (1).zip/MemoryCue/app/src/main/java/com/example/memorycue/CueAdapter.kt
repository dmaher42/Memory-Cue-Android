package com.example.memorycue

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class CueAdapter(private val onNotify: (String) -> Unit) :
    ListAdapter<String, CueAdapter.VH>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<String>() {
            override fun areItemsTheSame(oldItem: String, newItem: String) = oldItem == newItem
            override fun areContentsTheSame(oldItem: String, newItem: String) = oldItem == newItem
        }
    }

    class VH(val root: ViewGroup) : RecyclerView.ViewHolder(root) {
        val txt: TextView = root.findViewById(R.id.txtCue)
        val btn: Button = root.findViewById(R.id.btnNotify)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_cue, parent, false) as ViewGroup
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)
        holder.txt.text = item
        holder.btn.setOnClickListener { onNotify(item) }
    }
}
