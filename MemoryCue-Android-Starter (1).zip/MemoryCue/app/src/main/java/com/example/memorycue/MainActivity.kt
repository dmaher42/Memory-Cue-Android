package com.example.memorycue

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.memorycue.databinding.ActivityMainBinding

class MainActivity : ComponentActivity() {

    private lateinit var binding: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("cues", Context.MODE_PRIVATE) }
    private val adapter = CueAdapter { text -> scheduleReminder(text, 0) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        createNotificationChannel()

        binding.listCues.layoutManager = LinearLayoutManager(this)
        binding.listCues.adapter = adapter

        binding.btnAdd.setOnClickListener { addCue() }
        binding.inputCue.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                addCue(); true
            } else false
        }

        binding.btnRemind5.setOnClickListener {
            val text = binding.inputCue.text?.toString()?.ifBlank { null } ?: "Memory cue"
            scheduleReminder(text, 5 * 60 * 1000L)
        }

        // Load existing
        adapter.submitList(loadCues())
    }

    private fun addCue() {
        val text = binding.inputCue.text?.toString()?.trim()
        if (!text.isNullOrEmpty()) {
            val list = loadCues().toMutableList()
            list.add(0, text)
            prefs.edit().putString("data", list.joinToString("\n")).apply()
            adapter.submitList(list)
            binding.inputCue.setText("")
        }
    }

    private fun loadCues(): List<String> {
        val raw = prefs.getString("data", "") ?: ""
        return if (raw.isBlank()) emptyList() else raw.split("\n".toRegex())
    }

    private fun scheduleReminder(text: String, delayMs: Long) {
        val intent = Intent(this, ReminderReceiver::class.java).apply {
            putExtra("text", text)
        }
        val pi = PendingIntent.getBroadcast(
            this,
            System.currentTimeMillis().toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val triggerAt = System.currentTimeMillis() + delayMs
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "memcue",
                getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_HIGH
            )
            channel.description = getString(R.string.channel_desc)
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }
}
